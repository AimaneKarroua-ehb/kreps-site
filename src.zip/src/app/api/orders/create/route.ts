import { NextResponse } from "next/server";
import { supabaseAdmin } from "@/lib/supabaseAdmin";

function makeCode() {
  const rnd = crypto.randomUUID().slice(0, 8).toUpperCase();
  return `KREPS-${rnd}`;
}

export async function POST(req: Request) {
  try {
    const body = await req.json().catch(() => null);

    const totalCents = body?.totalCents;
    const items = body?.items;

    if (typeof totalCents !== "number" || !Array.isArray(items) || items.length === 0) {
      return NextResponse.json(
        { error: "Bad body: totalCents(number) + items(array) requis" },
        { status: 400 },
      );
    }

    const code = makeCode();

    const { data: order, error: oErr } = await supabaseAdmin
      .from("orders")
      .insert({
        code,
        status: "pending",
        total_cents: totalCents,
        customer_name: body?.customerName ?? null,
        customer_phone: body?.customerPhone ?? null,
        note: body?.note ?? null,
      })
      .select("id, code")
      .single();

    if (oErr) return NextResponse.json({ error: oErr.message }, { status: 500 });

    const rows = items.map((it: any) => ({
  order_id: order.id,
  name_snapshot: String(it.name ?? ""),
  unit_price_cents: Number(
    (it.basePriceCents ?? 0) + (it.optionPriceCents ?? 0)
  ),
  quantity: Number(it.quantity ?? 1),
  selected_options: it.selectedOptions ?? {},
}));

    const { error: iErr } = await supabaseAdmin.from("order_items").insert(rows);
    if (iErr) return NextResponse.json({ error: iErr.message }, { status: 500 });

    return NextResponse.json({ ok: true, orderId: order.id, code: order.code });
  } catch (e: any) {
    return NextResponse.json({ error: e?.message ?? "Unknown error" }, { status: 500 });
  }
}